const express = require('express');
const bodyParser= require('body-parser');
const session =require('express-session');
const mongoose = require('mongoose');
var path = require('path');

const routes= require('./routes/api');

//Set up  Express App
const app = express();

var up = require('express-fileupload');
var multer = require('multer');
app.use(up());


//set up template engine
app.set('view engine', 'ejs');

//Initialize Middleware
app.use('/asset', express.static('asset'));

// Using session in our App
app.use(session({secret: "abcdefgh", resave: false, saveUninitialized :true  })   );

//connect to mongodb
mongoose.connect('mongodb://localhost/BigDaddy');
mongoose.Promise= global.Promise;

//Serve Static File from Folder called "public"
app.use(express.static('public'));
//Initialize Body Parser
app.use(bodyParser.json());

//Initialize Routes
app.use('/api',routes);

//Error Handling Middleware
app.use(function(err, req, res, next)
{
//  console.log(err);
    res.status(422).send({error: err.message});
});


// listen for requests
app.listen(process.env.port || 4000, function()
{
  console.log('Listening For Requests!! ');
});
