const mongoose= require('mongoose');
const Schema =mongoose.Schema;


//create Sign up Schema And Model
const signupSchema =new Schema(
  {
    name:
    {
      type : String,
      required :[true, 'Name Required']
    },
    email:
    {
      type : String,
      required :[true, 'Password Required']
    },
    password:
    {
      type : String,
      required :[true, 'Password Required']
    },

    confirmpassword:
    {
      type : String,
      required :[true, 'Confirm Password Required']
    }
  }
);
//Store signup_db in database which has schema of "signupSchema"
// His Ninja is my "SignupModel"
const SignupModel= mongoose.model('signup_db',signupSchema);
// Export Signup Model in other files (may be in Post request)
module.exports= SignupModel;
