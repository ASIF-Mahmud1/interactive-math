const mongoose= require('mongoose');
const Schema =mongoose.Schema;


//create Login Schema And Model
const loginSchema =new Schema(
  {
    email :
    {
      type : String,
      required :[true, 'Name Required']
    },
    password:
    {
      type : String,
      required :[true, 'Password Required']
    }

  }
);

//Store signup_db in database which has schema of "signupSchema"

const LoginModel= mongoose.model('login_db',logSchema);
// Export Signup Model in other files (may be in Post request)
module.exports= LoginModel;
