const mongoose= require('mongoose');
const Schema =mongoose.Schema;


//create File Schema And Model
const fileSchema =new Schema(
  {
    name:
    {
      type : String,
      required :[true, 'Name Required']
    },
    path:
    {
      type : String,
      required :[true, 'Path Required']
    }

  }
);
//Store File_db in database which has schema of "fileSchema"
// His Ninja is my "SignupModel"
const FileModel= mongoose.model('UploadFile_db',fileSchema);
// Export Signup Model in other files (may be in Post request)
module.exports= FileModel;
