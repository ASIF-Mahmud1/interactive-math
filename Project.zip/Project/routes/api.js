const express= require('express');
const router= express.Router();
const bodyParser= require('body-parser');
//Import SignupModel from signup.js
const SignupModel =require('../models/signup');
///Inmport FileModel from file.js
const FileModel = require('../models/file');

var multer = require('multer');
var up = require('express-fileupload');
var path = require('path');

////////
// To get more info about 'multer'.. you can go through https://www.npmjs.com/package/multer..
var storage = multer.diskStorage({
 destination: function(req, file, cb) {
 cb(null, 'uploads/')
 },
 filename: function(req, file, cb) {
 cb(null, file.originalname);
 }
});

var upload = multer({
 storage: storage
});


var urlencodedParser= bodyParser.urlencoded({extended: false});





////////////////////////////


//SIGNUP ROUTES
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Get a List of Signup From the Database
// His Ninja is my "SignupModel"
router.get('/signup',function(req, res, next)
{
   //res.send({type:'GET Request Maen' });
   // find is a  mongoose method
   //Empty Curly Braces mean find all the Signup data fromc database
   // if you want to all Data from  "signup_db" open this below

  /* SignupModel.find({}).then(function(retieve_data)
 {
   res.send(retieve_data);
 }).catch(next);*/

 SignupModel.find({name :req.query.name}).then(function(retieve_data)
{
  res.send(retieve_data);
}).catch(next);

});

//sign up test you might want to delete it
router.get('/signupp',function(req, res, next)
{
  res.render('three');
});

// Add a new Signup to the Database

router.post("/four", urlencodedParser, function(req, res,next)
{
    //  console.log(req.body);
  var need =SignupModel(
    {

      name : req.body.name,
      email : req.body.email,
      password : req.body.password,
      confirmpassword : req.body.confirmpassword
    }
  ).save(function(err, doc) {
    if(err) res.json(err);
  else res.send("Successful maen");
  //else
//  SignupModel.find({}).then(function(retieve_data)
 //{
//   res.send(retieve_data);
 //}).catch(next);
  //else res.redirect('/api/one');
  });
});

// Update a Signup in the Database
router.put('/signup/:id',function(req, res, next)
{
  SignupModel.findByIdAndUpdate({_id: req.params.id}, req.body).then(function()
{
  SignupModel.findOne({_id: req.params.id}).then(function(update_info)
{
  console.log(update_info);
  res.send(update_info);
});

});
//  res.send({type:'PUT Request Maen' });
});

// Delete a Signup From the Database
router.delete('/signup/:id',function(req, res, next)
{
  // Find by id and remove is provided by mongoose
  SignupModel.findByIdAndRemove({_id: req.params.id}).then(function(removed_id)
{
 res.send(removed_id);
});
  // res.send({type:'DELETE Request Maen' });
});

//Ouput one.ejs
router.get('/', function(req,res)
	{
		res.render( 'fileupload');
	});

  router.post('/', function(req,res)
  	{
  		if(req.files)
      {
        console.log(req.files);
        var file= req.files.filename;
        var filename= file.name;
        file.mv("./upload/" + filename, function(err){
          if(err)
          {
            console.log(err);
            res.send("Error Occured");
          }
          else
          {
            res.send(filename);
          }
        });
      }
  	});

router.get('/one', function(req,res)
	{
    var counter=0;
    console.log(counter);
		res.render( 'one');
    FileModel.count({}, function(err, data){
      counter= data;
            console.log(">>>> " + data );});

console.log(counter);

	});
  /////////////////////
  router.get('/two', function(req,res)
  	{
  		res.render( 'two');

  	});

    router.post('/two', function(req,res)
      {
        res.redirect('/api/one');
      });

    /////////////////////
    router.get('/three', function(req,res)
      {
        res.render( 'three');
      });
      /////////////////////
      router.get('/four', function(req,res)
      	{
      		res.render( 'four');
      	});
        /////////////////////
        router.get('/five', function(req,res)
        	{
        		res.render( 'five');
        	});
          /////////////////////
          router.get('/six', function(req,res)
            {
              res.render( 'six');
            });




  //// LOGIN ROUTES
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

 router.post('/three',urlencodedParser, function(req, res )
{
  var Email = req.body.email;
  var Password= req.body.password;

  SignupModel.findOne({email : Email, password : Password }, function(err, user)
{
  if(err)
  {
    console.log("Write the parametres name correctly");
    alert("Write the parametres name correctly");
    return res.status(500).send();
  //  console.log(err);
  }
if(! user)
  {
    console.log("Incorrect User Name or Password . Try Agian");
    return res.status(404).send();
  }

 console.log("User Found");

 //req.session.user= user;
 res.redirect('/api/two');


// return res.status(200).send();
 });

}) ;


/////////////////////////////////////////////////////////////////////////////
//Session and Dashboard
router.get('/dashboard', function(req, res)
{
  if(! req.session.user)
  {
     return res.status(401).send("Not Logged In !!");
  }
     return res.status(200).send("Welcome to Your Account Maen");
});
///////////////////////////////////////////////////////////////////////////
/// LOG OUT ROUTES
router.get('/logout', function(req, res)
{
  req.session.destroy();
  return res.status(200).send("You Logged Out");
});

////////////////////////////////////////////////////////////////////////////////////
///Upload Files
  router.post('/five', function(req, res, next)
{
  if(req.files)
  {
    console.log(req.files);
    var file= req.files.filename;
    var filename= file.name;
    var filepath= "/upload/"+filename;

    file.mv("./upload/" + filename, function(err){
      if(err)
      {
        console.log(err);
        res.send("Error Occured");
      }
      else
      {
      //  res.send(filename);
      res.redirect('back');
 path = req.files.path;

    //  console.log(req.files);
        console.log("The Path Of File");
          console.log(filename);
      }
    });

///Upload Files to database
var need =FileModel(
  {

    name : filename,
    path : filepath
  }
).save(function(err, doc) {
  if(err) console.log("Something Went Wrong !!");
else  console.log("Congrats Brother Document Saved !!");

});






  }

}) ;






module.exports= router;
