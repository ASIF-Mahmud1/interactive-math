
////
var myform= document.getElementById('form');
var message= document.getElementById('message');
var array=[];
 function submit()
{
  if(myform.name.value=="" || myform.email.value=="" || myform.password.value=="" || myform.confirmpassword.value=="")
  {
    message.innerHTML="Please Fill Out Form Correctly";
    return false;
  }
  else
  {
     array= {name: myform.name.value, email: myform.email.value, password: myform.password.value, confirmpassword :myform.confirmpassword.value  };
    console.log(array);
    message.innerHTML="";
      return false;
  }

  $.ajax({
        type: 'POST',
        url: '/four',
        data: array,
        success: function(data){
          //do something with the data via front-end framework
        //  location.reload();
        }
      });
      return false;
};
