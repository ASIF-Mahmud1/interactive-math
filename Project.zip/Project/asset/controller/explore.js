var button =document.getElementById('Explore');
button.onclick= function pushdata1()
{
  console.log("You Clicked Me");
  $.ajax(
    {
      type:"GET",
      url: '/api/two',
      success : function(ddata){
        console.log(ddata);
        //console.log(response);
        window.location.replace('/api/two');
        alert("Login Successful");
}

    }
  );

};
