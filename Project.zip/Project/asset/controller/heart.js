

var name="Nothing";
var email="Nothing";
var password="Nothing";
var confirmpassword= "Nothing";
//var button= document.getElementById("signup");
var array= [];
  function pushdata()
{
  name= document.getElementById("name").value;
  email=document.getElementById("email").value;
  password=document.getElementById("password").value;
  confirmpassword=document.getElementById("confirmpassword").value;
  array= {name: name, email: email, password: password, confirmpassword :confirmpassword};
  console.log(array);

  $.ajax({
    type: 'POST',
    url: '/api/four',
    data:{name: name, email: email, password: password, confirmpassword :confirmpassword},
    success : function(ddata){

     console.log(ddata);
  //  array=ddata;



    },
    error : function(){
      alert("Error Maen!!");
    }
  });
    // return false;

};
