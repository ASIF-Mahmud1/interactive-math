
form.onsubmit= function(event)
{
  //event.preventDefault();

  ///Grab The File Bunch
  var fileselect= document.getElementById('file');
  //The actual File
  var files= fileselect.files;
  // The Path of the File
  var filePath = fileselect.value;
  //Type of the File
  var type= fileselect.type;
  //How Many File Type
  var lent= files.length;
  var file= files[0];

  console.log(file);
  console.log(filePath);
  console.log(type);

  console.log("Length of File ");
  console.log(lent);

  var allowedExtensions = /(\.pdf|\.docx|\.txt|\.pptx)$/i;
   if(!allowedExtensions.exec(filePath))
   {
       alert('Please upload file having extensions .pdf/.doc/.txt/.ppt only.');
       fileselect.value = '';
       return false;
   }

   else
   {
     // Create a new FormData object.
     var formData = new FormData();

     formData.append("file", document.getElementById('file').files[0]);
     console.log("Final File");
    // console.log(formData.getAll());
     console.log(...formData);
     // Display the key/value pairs
for(var pair of formData.entries()) {
   console.log(pair[0]+ ', '+ pair[1]);
}


        $.ajax({
         type: 'POST',
         url: '/',
         data: formData ,
         processData: false,
         cache:false,
        //  headers: { 'Content-Type': undefined },

         //contentType: false,



         success : function(ddata){

           console.log("Successfuly Listened From Server!!")
          console.log(ddata);
         },
         error : function(){
           alert("Error Maen!!");
         }
       });

   }






};











//document.getElementById('form').onsubmit(function(e) {
  // e.preventDefault();
   // do something
//});













/*

function pushdata()
{

  var fileselect= document.getElementById('the-file');

  var files= fileselect.files;
  var filePath = fileselect.value;
  var type= fileselect.type;
  var lent= files.length;
  var file= files[0];

  console.log(files);
  console.log(filePath);
  console.log(type);
//
  console.log("Length of File ");
  console.log(file);

  var allowedExtensions = /(\.pdf|\.docx|\.txt|\.ppt)$/i;
   if(!allowedExtensions.exec(filePath))
   {
       alert('Please upload file having extensions .pdf/.doc/.txt/.ppt only.');
       fileselect.value = '';
       return false;
   }

   else
   {
     // Create a new FormData object.
     var formData = new FormData();

     formData.append('file', file, file.name);
     console.log("Final File");
     console.log(file.name);
     console.log(formData);


        $.ajax({
         type: 'POST',
         url: '/api/five',
         data: {file :file} ,
         processData: false,


         //contentType: false,



         success : function(ddata){

           console.log("Successfuly Listened From Server!!")
          console.log(ddata);
         },
         error : function(){
           alert("Error Maen!!");
         }
       });

   }




}; */
