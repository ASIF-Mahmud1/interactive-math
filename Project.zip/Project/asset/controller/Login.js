

var email="Nothing";
var password="Nothing";
//var button= document.getElementById("signup");
var array= [];
  function pushdata()
{
  email=document.getElementById("email").value;
  password=document.getElementById("password").value;
  array= { email: email, password: password};
  console.log(array);
  if(email=="" || password=="")
  {
  alert("Please Fill Out Form Correctly");
    return false;
  }
  else{

  $.ajax({
    type: 'POST',
    url: '/api/three',
    data:{ email: email, password: password},
    success : function(ddata){
      console.log(ddata);
      //console.log(response);
      window.location.replace('/api/one');
      alert("Login Successful");
    },
    error : function(){
      alert("User Not Found");
    }
  });
    // return false;
  }

};
